package p32929.passcodelock;

public interface ChangeText {
    public void change(Boolean status);
}
